package com.finalprj.demo;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProdFinaldemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProdFinaldemoApplication.class, args);
	}

}


